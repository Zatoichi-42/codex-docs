# Concept Map: Claude Bootstrap → Codex Bootstrap

## Global setup

| Claude bootstrap concept | Codex equivalent | Fidelity | Notes |
| --- | --- | --- | --- |
| `~/.claude/CLAUDE.md` | `~/.codex/AGENTS.md` | Very close | Same role: persistent developer instructions loaded before work. |
| `settings.json` permissions | `~/.codex/config.toml` plus `.rules` plus approvals | Close | Codex splits policy across config, approvals, and shell rules. |
| `commands/` | skills + native slash commands | Close | Codex does not use arbitrary markdown slash commands the same way. Skills are the best reusable workflow unit. |
| `rules/*.md` path triggers | skills + nested `AGENTS.md` | Approximate | Codex rules are shell execution rules, not path-based prompt layers. |
| event hooks | `hooks.json` | Very close for session/prompt/bash/stop | Write hooks do not port exactly. |

## Workflows

| Claude concept | Codex port |
| --- | --- |
| Six Step loop | `.agents/skills/six-step-loop` |
| Feature workflow (`/build`) | `.agents/skills/feature-workflow` plus Build Sequence enforcement in `user_prompt_submit.py` |
| Ratchet workflow (`/evolve`) | `.agents/skills/ratchet-evolve` + `scripts/ratchet_gate.py` |
| Status workflow (`/status`) | native `/status`, native `/review`, and `.agents/skills/project-status` |

## Hooks

| Claude hook | Codex port | Notes |
| --- | --- | --- |
| `session-start.sh` | `session_start.py` | Loads branch, journal, TODO, ratchet summary into extra context. |
| `pre-tool-security.sh` | `pre_tool_security.py` | Blocks dangerous Bash and sensitive-path writes attempted through Bash. |
| `pre-write-guard.sh` | no literal equivalent | Replaced by AGENTS rules, testing-guard skill, and TDD subagent constraints. |
| `post-edit-autoformat.sh` | no literal equivalent | Replaced by stage validation rules and explicit formatter commands. |
| `stop-journal.sh` | `stop_journal.py` | Writes `.codex/JOURNAL.md` and `.codex/HANDOFF.md`. |
| `impl-protocol-reminder.sh` | `user_prompt_submit.py` | Injects the live Build Sequence, points to the first unchecked step, and honors `/quick` as a single-prompt bypass. |
| `notify.sh` | `notify.py` or native `notify` config | Best-effort notification command. |
| `subagent-start.sh` | none required | Codex child agents inherit active runtime choices and can be customized by TOML. |
| `post-compact-handoff.sh` | covered by stop journaling | Codex compaction exists, but stop journaling is the more generally useful portable behavior. |

## Agents

| Claude concept | Codex equivalent |
| --- | --- |
| `.claude/agents/*.md` | `.codex/agents/*.toml` |
| prompt-evolving agents | custom agents + deterministic gate script |
| specialized test writer | `tdd-test-writer.toml` |
| docs lookup specialist | `docs-researcher.toml` |
| review specialist | `reviewer.toml` |

## Safety model

| Claude concept | Codex equivalent |
| --- | --- |
| allow/deny permissions list | approval policy + sandbox + shell rules + Bash pre-tool hook |
| block secret commits | pre-tool Bash hook checks staged files |
| block force push to main/master | shell rules plus Bash hook |
| prevent unsafe shell patterns | shell rules plus Bash hook |

## Gaps you should accept instead of hiding

1. Codex does not currently provide write/edit hooks that mirror Claude's write tool events.
2. Codex rules control shell execution, not file-pattern instruction overlays.
3. Codex native slash commands are fixed; reusable custom workflow logic belongs in skills.

## Recommended usage pattern

- Put durable policy in `AGENTS.md`
- Put reusable workflows in skills
- Put execution policy in `.rules` and Bash hooks
- Put specialized delegation in custom subagents
- Put status and continuity in journaling scripts
