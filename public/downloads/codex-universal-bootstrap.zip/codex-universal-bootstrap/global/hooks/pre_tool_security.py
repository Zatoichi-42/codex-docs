#!/usr/bin/env python3

import json
import re
import subprocess
import sys

payload = json.load(sys.stdin) if not sys.stdin.isatty() else {}
command = (((payload.get("tool_input") or {}).get("command")) or "").strip()

BLOCK_PATTERNS = [
    (r"\bsudo\b", "Privilege escalation is blocked by the bootstrap."),
    (r"curl\s+[^|]+\|\s*(bash|sh)", "curl-pipe-shell is blocked by the bootstrap."),
    (r"wget\s+[^|]+\|\s*(bash|sh)", "wget-pipe-shell is blocked by the bootstrap."),
    (r"\brm\s+-rf\s+(/|~|\.git)(\s|$)", "Recursive deletion of critical paths is blocked."),
    (r"git\s+push.*(--force|-f).*(main|master)", "Force push to main/master is blocked."),
    (r"(echo|printf|cat).*?>.*\.(env|key|pem)(\s|$)", "Writing directly to sensitive file types through shell redirection is blocked."),
    (r"\bchmod\s+777\b", "chmod 777 is blocked by the bootstrap."),
    (r"\bmkfs\b|\bdd\b", "Disk-destructive commands are blocked by the bootstrap.")
]

for pattern, reason in BLOCK_PATTERNS:
    if re.search(pattern, command, flags=re.IGNORECASE):
        print(json.dumps({
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": reason
            }
        }))
        raise SystemExit(0)

if command.startswith("git add") or command.startswith("git commit"):
    try:
        staged = subprocess.check_output(["git", "diff", "--cached", "--name-only"], stderr=subprocess.DEVNULL, text=True)
    except Exception:
        staged = ""
    sensitive = [line for line in staged.splitlines() if re.search(r"(^|/)(\.env[^/]*|.*\.(pem|key)|credentials)(\.|$|/)", line, flags=re.IGNORECASE)]
    if sensitive:
        print(json.dumps({
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": f"Sensitive staged files detected: {', '.join(sensitive[:5])}"
            }
        }))
        raise SystemExit(0)

