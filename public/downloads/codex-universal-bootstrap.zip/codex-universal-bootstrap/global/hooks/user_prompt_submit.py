#!/usr/bin/env python3

import json
import re
import sys
from pathlib import Path


def load_payload() -> dict:
    if sys.stdin.isatty():
        return {}
    try:
        return json.load(sys.stdin)
    except Exception:
        return {}


def emit(message: str) -> None:
    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "UserPromptSubmit",
            "additionalContext": message,
        }
    }))


def first_line(text: str) -> str:
    return text.splitlines()[0] if text.splitlines() else text


def find_agents_md(start: Path) -> Path | None:
    current = start.resolve()
    if current.is_file():
        current = current.parent
    for candidate in [current, *current.parents]:
        path = candidate / "AGENTS.md"
        if path.exists():
            return path
    return None


def extract_section(text: str, heading: str) -> str:
    pattern = re.compile(rf"^##\s+{re.escape(heading)}\s*$", re.MULTILINE)
    match = pattern.search(text)
    if not match:
        return ""
    start = match.end()
    rest = text[start:]
    next_heading = re.search(r"^##\s+", rest, re.MULTILINE)
    return rest[: next_heading.start()] if next_heading else rest


def normalize_ws(text: str) -> str:
    return "\n".join(line.rstrip() for line in text.strip().splitlines()).strip()


payload = load_payload()
prompt = (payload.get("prompt") or "").strip()
if not prompt:
    raise SystemExit(0)

cwd_value = payload.get("cwd") or str(Path.cwd())
cwd = Path(cwd_value)
line1 = first_line(prompt).strip()

if re.match(r"^/quick(?:\s|$)", line1, flags=re.IGNORECASE):
    emit("/quick bypass active for this prompt. Skip Build Sequence enforcement once and perform the requested task directly.")
    raise SystemExit(0)

agents_path = find_agents_md(cwd)
format_help = (
    "Missing Build Sequence. Add a `## Build Sequence` section to the nearest AGENTS.md with checkbox steps, phase gates, "
    "and a `## Test Command` section. Use `/quick <task>` on the first line only for a one-off bypass."
)

if agents_path is None:
    emit(f"STOP: No AGENTS.md found in scope for {cwd}. {format_help}")
    raise SystemExit(0)

text = agents_path.read_text(encoding="utf-8")
build_sequence = normalize_ws(extract_section(text, "Build Sequence"))
test_command = normalize_ws(extract_section(text, "Test Command"))

if not build_sequence:
    emit(f"STOP: The AGENTS.md at {agents_path} has no usable `## Build Sequence` section. {format_help}")
    raise SystemExit(0)

unchecked = re.findall(r"^- \[ \]\s+(.+)$", build_sequence, flags=re.MULTILINE)
if not unchecked:
    emit(
        f"All Build Sequence steps are complete in {agents_path}. Do not start a new stage until the user adds new unchecked steps or explicitly requests the next plan."
    )
    raise SystemExit(0)

current_step = unchecked[0]
extra = [
    f"LIVE BUILD SEQUENCE from {agents_path}",
    "",
    "Format: `- [ ]` = current or future work, `- [x]` = done, `**Gate:**` = must be satisfied before advancing, `/quick <task>` = one-prompt bypass.",
    "",
    build_sequence,
    "",
    f"CURRENT STEP: {current_step}",
]
if test_command:
    extra.extend(["", f"TEST COMMAND:\n{test_command}"])
extra.extend([
    "",
    "Instruction: work the first unchecked step only. Run the test command after each meaningful step. When the current phase gate is satisfied, stop, summarize, simplify changed files, produce the audit table, and ask whether to implement suggestions.",
])
emit("\n".join(extra))
