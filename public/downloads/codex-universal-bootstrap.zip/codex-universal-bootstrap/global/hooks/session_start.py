#!/usr/bin/env python3

import json
import subprocess
from pathlib import Path


def run(cmd):
    try:
        return subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True).strip()
    except Exception:
        return ""


cwd = Path.cwd()
branch = run(["git", "branch", "--show-current"]) or "not-in-git"
modified = run(["git", "diff", "--name-only"])
modified_count = len([x for x in modified.splitlines() if x.strip()]) if modified else 0
latest_commits = run(["git", "log", "--oneline", "-3"]) or "none"

journal_path = cwd / ".codex" / "JOURNAL.md"
blocked_path = cwd / ".codex" / "BLOCKED.md"
todo_candidates = [cwd / "TODO.md", cwd / ".codex" / "TODO.md"]

journal = journal_path.read_text(errors="ignore")[:4000] if journal_path.exists() else ""
blocked = blocked_path.read_text(errors="ignore")[:2000] if blocked_path.exists() else ""

done = remaining = None
for todo in todo_candidates:
    if todo.exists():
        text = todo.read_text(errors="ignore")
        done = sum(1 for line in text.splitlines() if line.startswith("- [x]"))
        remaining = sum(1 for line in text.splitlines() if line.startswith("- [ ]"))
        break

task_summary = "unknown"
if done is not None and remaining is not None:
    task_summary = f"{done} done / {done + remaining} total ({remaining} remaining)"

msg = f"Bootstrap context: branch={branch}; modified_files={modified_count}; tasks={task_summary}."
if latest_commits:
    msg += f" Recent commits: {latest_commits}"
if journal:
    msg += f" Previous journal:\n{journal}"
if blocked:
    msg += f"\nBlocked items:\n{blocked}"

print(json.dumps({
    "hookSpecificOutput": {
        "hookEventName": "SessionStart",
        "additionalContext": msg,
    }
}))
