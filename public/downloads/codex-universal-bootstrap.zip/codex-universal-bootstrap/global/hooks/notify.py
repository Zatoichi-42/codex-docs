#!/usr/bin/env python3

import json
import subprocess
import sys

payload = json.load(sys.stdin) if not sys.stdin.isatty() else {}
title = payload.get("title") or "Codex"
message = payload.get("message") or payload.get("event") or "Action needed"

commands = [
    ["osascript", "-e", f'display notification "{message}" with title "{title}"'],
    ["notify-send", title, message],
]
for cmd in commands:
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        raise SystemExit(0)
    except Exception:
        pass
print("\a", end="")

