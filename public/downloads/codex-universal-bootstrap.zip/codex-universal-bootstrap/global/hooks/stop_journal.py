#!/usr/bin/env python3

import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path

payload = json.load(sys.stdin) if not sys.stdin.isatty() else {}
if payload.get("stop_hook_active"):
    raise SystemExit(0)

cwd = Path.cwd()
codex_dir = cwd / ".codex"
codex_dir.mkdir(exist_ok=True)


def run(cmd):
    try:
        return subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True).strip()
    except Exception:
        return ""


branch = run(["git", "branch", "--show-current"]) or "unknown"
modified = run(["git", "diff", "--name-only"]) or ""
modified_count = len([x for x in modified.splitlines() if x.strip()]) if modified else 0
commits = run(["git", "log", "--oneline", "-3"]) or "none"

next_tasks = "none"
for todo in [cwd / "TODO.md", cwd / ".codex" / "TODO.md"]:
    if todo.exists():
        tasks = [line for line in todo.read_text(errors="ignore").splitlines() if line.startswith("- [ ]")]
        next_tasks = "\n".join(tasks[:3]) if tasks else "none"
        break

journal = f"# Journal — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
journal += f"Branch: {branch} | {modified_count} uncommitted files\n"
journal += f"Recent commits:\n{commits}\n"
journal += f"Next tasks:\n{next_tasks}\n"
journal += "Resume: read this file, inspect git diff, run the narrowest relevant validation, continue the next incomplete step.\n"

(codex_dir / "JOURNAL.md").write_text(journal)
(codex_dir / "HANDOFF.md").write_text(journal)

print(json.dumps({
    "hookSpecificOutput": {
        "hookEventName": "Stop",
        "stopReason": "Journal updated",
    }
}))
