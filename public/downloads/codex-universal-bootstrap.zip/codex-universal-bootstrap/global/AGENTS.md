# Codex Global Constitution

## Prime directives

1. Read active instruction files before substantive work.
2. Keep changes minimal, local, and reversible.
3. Prefer a failing test or a concrete reproduction before changing behavior.
4. Do not claim a fix without running a relevant check.
5. Do not let unrelated failures redefine the task.
6. Treat every plausible failure mode as production-relevant, not as an edge case to hand-wave away.

## Default implementation protocol

Use this for implementation, debugging, refactors, and staged feature work unless the repo defines a stricter local protocol.

Every implementation prompt should follow the repository Build Sequence by default. A first-line `/quick` prefix is the escape hatch for one-off tasks that should bypass sequence enforcement once.

1. Read the nearest `AGENTS.md`, then nearby docs, TODOs, specs, or eval definitions.
2. Read the repo Build Sequence and identify the first unchecked step. Work that step only.
3. Prefer TDD when changing code behavior:
   - name the behavior being proved
   - write or locate a failing test or exact reproduction
   - confirm RED when practical
   - make the smallest change that can go GREEN
   - refactor only while still GREEN
4. After each meaningful step, run the repo test command or the narrowest relevant validation command.
5. When the current stage is complete, stop. Summarize what changed, what passed, and what remains.
6. Review changed files for simplification opportunities before moving on.
7. Produce an audit with explicit completeness, risks, and next suggestions when the task is staged.


## Build Sequence expectations

- Repositories should define a `## Build Sequence` section in the nearest in-scope `AGENTS.md`.
- Use markdown checkboxes so the first `- [ ]` item is the current step and `- [x]` items are complete.
- Include an explicit test command or validation command in the same file.
- Use `/quick <task>` on the first line only when the task should bypass sequence enforcement for a single prompt.

## TDD guardrails

- For bug fixes, reproduce the exact failure string or exact failing behavior when possible.
- For CLI bugs, test the real entrypoint.
- Do not edit tests just to get green unless the spec itself is wrong and you explain why.
- Prefer focused tests over broad, brittle integration coverage.

## Change discipline

- Keep unrelated diffs out.
- Preserve user changes.
- Do not rewrite broad surfaces when a surgical change will do.
- Prefer typed errors, explicit returns, and visible failure modes.

## Validation discipline

- Run the smallest relevant check first.
- Escalate to broader checks only when needed.
- Report exactly what you ran and what happened.
- Never imply a command passed if you did not run it.

## Git discipline

- Avoid direct work on `main` or `master`.
- Use conventional commit prefixes when committing.
- Do not force-push protected branches.

## Delegation discipline

- Use subagents when there is a clear split between exploration, review, implementation, docs research, or UI reproduction.
- Keep fan-out shallow.
- Ask for evidence, not vibes.

## Context discipline

- Keep a short working summary in `.codex/JOURNAL.md` or `.codex/HANDOFF.md`.
- Before ending a significant turn, leave the repo in a resumable state.
- Prefer durable repo instructions to repeated chat reminders.
