# Codex Universal Bootstrap

A Codex-native port of the Claude Code universal bootstrap in `claude.zip`.

This package aims for concept-for-concept parity where Codex has a real primitive, and a close substitute where it does not.

## What this gives you

- Global and repo-scoped instructions through `AGENTS.md`
- Codex-native hooks through `hooks.json`
- Build Sequence enforcement for implementation prompts, with `/quick` as the single-prompt bypass
- A conservative default sandbox and approval setup
- Repo-scoped skills for the Six Step loop, feature workflow, ratchet workflow, status workflow, and focused guardrails
- Custom subagents for TDD, review, docs research, UI debugging, and ratchet auditing
- Helper scripts for status, journaling, bootstrap validation, and deterministic ratchet gating
- Install scripts for both global and project setup

## Structure

```text
codex-universal-bootstrap/
├── README.md
├── CONCEPT_MAP.md
├── GLOBAL_SETUP.md
├── install-global.sh
├── install-project.sh
├── global/
│   ├── AGENTS.md
│   ├── config.toml
│   ├── hooks.json
│   ├── rules/default.rules
│   └── hooks/
│       ├── session_start.py
│       ├── pre_tool_security.py
│       ├── user_prompt_submit.py
│       ├── stop_journal.py
│       └── notify.py
└── project-template/
    ├── AGENTS.md
    ├── .codex/
    │   ├── config.toml
    │   ├── hooks.json
    │   ├── hooks/
    │   │   ├── session_start.py
    │   │   ├── pre_tool_security.py
    │   │   ├── user_prompt_submit.py
    │   │   ├── stop_journal.py
    │   │   └── notify.py
    │   └── agents/
    │       ├── reviewer.toml
    │       ├── docs-researcher.toml
    │       ├── tdd-test-writer.toml
    │       ├── ui-debugger.toml
    │       └── ratchet-auditor.toml
    ├── .agents/skills/
    │   ├── six-step-loop/SKILL.md
    │   ├── feature-workflow/SKILL.md
    │   ├── ratchet-evolve/SKILL.md
    │   ├── project-status/SKILL.md
    │   ├── testing-guard/SKILL.md
    │   ├── ui-guard/SKILL.md
    │   └── safety-guard/SKILL.md
    ├── config/evolution-config.toml
    └── scripts/
        ├── bootstrap_doctor.py
        ├── project_status.py
        └── ratchet_gate.py
```

## Philosophy

- Prefer Codex-native mechanisms over imitation.
- Preserve the original operating model: staged work, TDD, stop-at-boundary discipline, journaling, safe execution, and ratchet improvement.
- Do not fake parity where the host cannot provide it.
- Keep the bootstrap small enough that teams can actually live with it.

## What is exact or very close

- Claude global constitution → Codex global `AGENTS.md`
- Claude project constitution → repo `AGENTS.md`
- Claude session-start hook → Codex `SessionStart`
- Claude prompt reminder hook → Codex `UserPromptSubmit` with live Build Sequence injection
- Claude bash security hook → Codex `PreToolUse` for `Bash`
- Claude stop journal → Codex `Stop`
- Claude `/build`, `/evolve`, `/status` workflows → Codex skills, hook-enforced build sequence, and native `/status` and `/review`
- Claude agents → Codex custom subagents
- Claude permissions → Codex sandbox, approvals, and shell rules

## What is approximate

1. **Write/Edit hooks**
   Codex hooks currently target `Bash` tool traffic rather than file-write events. That means Claude's `Write|Edit|MultiEdit` guards do not have a literal port.

   Compensation in this bootstrap:
   - stronger `AGENTS.md` rules
   - focused guard skills
   - explicit TDD subagent boundaries
   - journaling and audit discipline

2. **Post-edit autoformat**
   There is no direct post-file-write hook. The substitute is procedural:
   - instructions in `AGENTS.md`
   - optional formatter commands in stage validation
   - review pass before stage closure

3. **Path-scoped rules**
   Claude rule files can fire by path pattern. Codex `rules` are for shell execution policy, not for file-pattern instruction injection.

   Compensation in this bootstrap:
   - nested `AGENTS.md` where needed
   - repo skills with strong trigger descriptions
   - custom agents for special-purpose work

## Suggested rollout

1. Install the global files once.
2. Copy the project template into a repository.
3. Edit the repo `AGENTS.md` so the Build Sequence, Test Command, and service-specific facts are real.
4. Run `/status` and inspect the active config.
5. By default, implementation prompts now follow the Build Sequence. Use `/quick <task>` only for a one-off bypass.
6. Invoke `$feature-workflow` or ask Codex to follow the six-step loop for the first real task.

## Opinionated defaults

- `sandbox_mode = "workspace-write"`
- `approval_policy = "on-request"`
- network disabled in workspace-write mode unless you explicitly turn it on
- project fallback instruction names include `CLAUDE.md`, `TEAM_GUIDE.md`, and `.agents.md`
- agent fan-out kept shallow by default

## Notes

- This bootstrap intentionally uses **skills** for the reusable workflow layer, because they are the cleanest Codex-native analogue to Claude commands plus helper docs.
- The repo template is safe to commit.
- The global template is designed for `~/.codex/`.
