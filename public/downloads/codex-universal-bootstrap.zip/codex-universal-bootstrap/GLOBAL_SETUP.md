# Global Setup

This mirrors the spirit of the Claude global setup while respecting how Codex actually works.

## One-time global install

```bash
bash install-global.sh
```

That installs the following into `~/.codex/`:

- `AGENTS.md`
- `config.toml`
- `hooks.json`
- `hooks/*.py`
- `rules/default.rules`

## Per-repository install

From the repository root:

```bash
bash /path/to/codex-universal-bootstrap/install-project.sh
```

That copies:

- `AGENTS.md`
- `.codex/config.toml`
- `.codex/hooks.json`
- `.codex/hooks/*.py`
- `.codex/agents/*.toml`
- `.agents/skills/*`
- `config/evolution-config.toml`
- `scripts/*.py`

## First edits to make

### 1. Edit repo `AGENTS.md`

Replace placeholder sections with:

- the real Build Sequence using checkbox steps
- the real Test Command
- repo-specific boundaries
- service or package level instructions

Without a real Build Sequence, the prompt hook will steer Codex to stop and ask for one unless you deliberately use `/quick <task>` on the first line.

### 2. Set trust for the repo if needed

If the repository is not already trusted, trust it in your Codex config or launch from a trusted project location.

### 3. Confirm status

Run:

```text
/status
```

Check that the sandbox, approvals, and writable roots match your expectations.

### 4. Start a first task

Examples:

```text
$feature-workflow implement the current stage only
```

```text
Follow the six-step loop to fix the failing login redirect.
```

```text
$project-status
```

## Optional refinements

### Add service-specific nested `AGENTS.md`

For directories with special rules, add a closer `AGENTS.md` or `AGENTS.override.md`.

### Turn on network inside the sandbox

Edit `.codex/config.toml`:

```toml
[sandbox_workspace_write]
network_access = true
```

Only do that when the repository genuinely needs package installs or live API access.

### Wire a notification command

Edit `~/.codex/config.toml` and set `notify` if you want native notifications.

## Operational advice

- Keep the global `AGENTS.md` stable and general.
- Put project truth in the repo `AGENTS.md`.
- Use skills for repeatable workflows instead of overstuffing `AGENTS.md`.
- Keep agent depth shallow.
- Prefer deterministic checks over “looks good” language.
