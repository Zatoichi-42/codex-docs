#!/usr/bin/env bash
set -euo pipefail

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${HOME}/.codex"

mkdir -p "${TARGET_DIR}" "${TARGET_DIR}/hooks" "${TARGET_DIR}/rules"

cp "${SRC_DIR}/global/AGENTS.md" "${TARGET_DIR}/AGENTS.md"
cp "${SRC_DIR}/global/config.toml" "${TARGET_DIR}/config.toml"
cp "${SRC_DIR}/global/hooks.json" "${TARGET_DIR}/hooks.json"
cp -R "${SRC_DIR}/global/hooks/." "${TARGET_DIR}/hooks/"
cp "${SRC_DIR}/global/rules/default.rules" "${TARGET_DIR}/rules/default.rules"
chmod +x "${TARGET_DIR}/hooks/"*.py || true

echo "Installed global Codex bootstrap to ${TARGET_DIR}"
echo "Next: run install-project.sh inside a repository and then edit that repo's AGENTS.md"
