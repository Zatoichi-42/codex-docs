---
name: ui-guard
description: apply frontend and interface guardrails when changing components, pages, or client flows. use when codex is editing tsx, jsx, vue, svelte, or other user-facing interface code.
---

## Rules

- Keep components focused and small.
- Keep business logic out of presentational components when possible.
- Preserve keyboard access, labels, alt text, semantic HTML, and contrast.
- Validate the layouts that matter to the repo, with 320/768/1024 as the minimum default check set when no better local breakpoints are specified.
- Report exact UI evidence instead of assuming visual behavior.
