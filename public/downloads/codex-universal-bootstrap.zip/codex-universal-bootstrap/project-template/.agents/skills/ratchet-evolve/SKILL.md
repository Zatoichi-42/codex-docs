---
name: ratchet-evolve
description: run a deterministic ratchet loop to improve prompts, instructions, agent definitions, or workflow files while protecting against regressions. use when codex is evolving the bootstrap, a skill, or an agent and should keep only measurable improvements.
---

Use this workflow for controlled self-improvement.

## Procedure

1. Read `config/evolution-config.toml` and the artifact under test.
2. Define the protected metrics and the weak metric.
3. Capture a baseline result.
4. Create one focused candidate mutation.
5. Evaluate baseline and candidate with deterministic checks.
6. Apply the ratchet gate:
   - candidate must improve the weak metric by at least the configured minimum
   - candidate must not regress any protected metric beyond the configured maximum
7. Keep only passing mutations.
8. Log the comparison and the decision.

## Required outputs

- baseline metrics
- candidate metrics
- keep or reject
- exact reason
- next mutation idea
