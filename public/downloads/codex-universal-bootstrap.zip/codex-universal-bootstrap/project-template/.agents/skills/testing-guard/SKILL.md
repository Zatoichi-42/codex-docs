---
name: testing-guard
description: apply strict testing discipline when working on test files, reproductions, or regression coverage. use when codex is writing tests, changing test infrastructure, or fixing bugs that need exact reproduction.
---

## Rules

- Tests are the specification.
- Prefer one behavior per test.
- Reproduce exact failures when available.
- Do not weaken tests to make implementation look correct.
- Do not mock the unit under test unless there is a clear boundary reason.
- For CLI work, test the actual entrypoint when practical.
