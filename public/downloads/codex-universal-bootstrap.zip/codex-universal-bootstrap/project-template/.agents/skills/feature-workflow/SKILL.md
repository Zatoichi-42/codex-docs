---
name: feature-workflow
description: execute staged feature work or a staged todo/spec workflow one step at a time. use when the repository has a build sequence, todo list, staged plan, or explicit current step and codex must not build ahead.
---

Use this workflow for staged implementation.

## Procedure

1. Read the nearest `AGENTS.md`, TODO, staged spec, or roadmap.
2. Read the Build Sequence and identify the **first unchecked** step.
3. Confirm the acceptance signal and test command for just that step.
4. Implement only the current step.
5. Run the relevant tests or validations for that step.
6. Stop at the current phase gate.
7. Produce this audit table:

| Item | Complete % | Reason | Suggestion |
| --- | --- | --- | --- |

Use only `0`, `50`, or `100` for Complete % and justify from evidence.

## Guardrails

- Build Sequence enforcement is the default for implementation prompts.
- `/quick <task>` bypasses Build Sequence enforcement for one prompt only.
- Do not build ahead.
- Do not mark a step complete from intent alone.
- Keep the repo resumable.
