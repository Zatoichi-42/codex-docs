---
name: project-status
description: produce a fast evidence-based project health summary for the current repository. use when the user asks for status, current stage, git state, test state, or readiness to continue.
---

Use this workflow to summarize the repository in under a minute.

## Check

1. Current stage from `AGENTS.md`, TODOs, or staged docs
2. Git branch and uncommitted files
3. Journal and handoff notes
4. Most relevant test command and current result, if safe and known
5. Recent commits
6. Obvious drift between declared workflow and actual files

## Output

Return a concise summary with:

- stage now
- next step
- git summary
- test summary
- risks or blockers
