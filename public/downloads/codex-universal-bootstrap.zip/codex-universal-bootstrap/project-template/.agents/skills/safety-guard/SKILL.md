---
name: safety-guard
description: apply security and shell-safety guardrails when editing scripts, hooks, env handling, docker files, or sensitive automation. use when codex is touching shell scripts, hook files, docker files, or secrets-related paths.
---

## Rules

- Never hardcode secrets.
- Never commit `.env` material.
- Never use `curl | bash` or `wget | bash` in generated automation.
- Avoid world-writable permissions.
- Quote variables in shell and prefer explicit failure handling.
- Favor the smallest necessary privilege and the smallest blast radius.
