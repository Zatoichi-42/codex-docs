---
name: six-step-loop
description: run a strict six-step implementation loop for coding tasks such as fixing bugs, adding small features, refactoring behavior, or working through a staged spec. use when codex should follow disciplined understand→red→green→validate→audit behavior instead of jumping straight to edits.
---

Use this workflow for implementation tasks.

## Steps

1. **Understand**
   Read the nearest `AGENTS.md`, the current task, and the smallest set of files needed to identify the owning code path.

2. **Reproduce or specify**
   State the exact behavior to preserve or change. For bug work, prefer an exact reproduction or precise failing condition.

3. **Get RED when practical**
   Write or locate the narrowest test or reproduction that fails for the right reason.

4. **Make the smallest GREEN change**
   Edit only the files needed to satisfy the failing behavior.

5. **Validate after each meaningful step**
   Run the narrowest relevant command first. Escalate only when needed.

6. **Audit and stop**
   Summarize what changed, what passed, any remaining gaps, and suggestions for the next step. Do not silently continue into the next stage.

## Required output

At the end of the turn, report:

- owning files touched
- validation commands run
- current status: RED, GREEN, or PARTIAL
- next suggested step
