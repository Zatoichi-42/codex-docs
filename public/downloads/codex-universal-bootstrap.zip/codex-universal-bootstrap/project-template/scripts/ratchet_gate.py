#!/usr/bin/env python3
import json
import sys
from pathlib import Path

if len(sys.argv) != 4:
    print("Usage: ratchet_gate.py <config.toml ignored-for-now> <baseline.json> <candidate.json>")
    raise SystemExit(2)

_, _config, baseline_path, candidate_path = sys.argv
baseline = json.loads(Path(baseline_path).read_text())
candidate = json.loads(Path(candidate_path).read_text())

min_improvement = 0.05
max_regression = 0.0
focus = candidate.get("focus_metric") or baseline.get("focus_metric") or "score"

base_focus = float(baseline["metrics"].get(focus, 0.0))
cand_focus = float(candidate["metrics"].get(focus, 0.0))
improvement = cand_focus - base_focus

regressions = {}
for key, base_val in baseline["metrics"].items():
    cand_val = float(candidate["metrics"].get(key, base_val))
    delta = cand_val - float(base_val)
    if delta < -max_regression:
        regressions[key] = delta

keep = improvement >= min_improvement and not regressions
result = {
    "focus_metric": focus,
    "baseline": baseline["metrics"],
    "candidate": candidate["metrics"],
    "improvement": improvement,
    "regressions": regressions,
    "decision": "keep" if keep else "reject"
}
print(json.dumps(result, indent=2, sort_keys=True))
raise SystemExit(0 if keep else 1)
