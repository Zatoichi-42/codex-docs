#!/usr/bin/env python3
from pathlib import Path
import re
import sys

required = [
    Path("AGENTS.md"),
    Path(".codex/config.toml"),
    Path(".codex/hooks.json"),
    Path("config/evolution-config.toml"),
    Path("scripts/project_status.py"),
]

missing = [str(p) for p in required if not p.exists()]
if missing:
    print("Bootstrap doctor: missing files")
    for item in missing:
        print(f"- {item}")
    raise SystemExit(1)

agents_text = Path("AGENTS.md").read_text(errors="ignore")
issues = []
if "## Build Sequence" not in agents_text:
    issues.append("AGENTS.md is missing a `## Build Sequence` section")
if "## Test Command" not in agents_text:
    issues.append("AGENTS.md is missing a `## Test Command` section")
if not re.search(r"^- \[ \] ", agents_text, flags=re.MULTILINE):
    issues.append("AGENTS.md has no unchecked `- [ ]` Build Sequence items")
if "/quick <task>" not in agents_text and "`/quick" not in agents_text:
    issues.append("AGENTS.md does not document the `/quick <task>` bypass")

if issues:
    print("Bootstrap doctor: configuration issues")
    for item in issues:
        print(f"- {item}")
    raise SystemExit(1)

skills_dir = Path(".agents/skills")
skills = sorted(p.parent.name for p in skills_dir.glob("*/SKILL.md")) if skills_dir.exists() else []
print("Bootstrap doctor: OK")
print(f"Skills: {', '.join(skills) if skills else 'none'}")
