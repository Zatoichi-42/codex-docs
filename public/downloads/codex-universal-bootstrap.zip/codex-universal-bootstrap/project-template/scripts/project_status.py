#!/usr/bin/env python3
from pathlib import Path
import re
import subprocess


def run(cmd):
    try:
        return subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True).strip()
    except Exception:
        return ""


def extract_section(text: str, heading: str) -> str:
    pattern = re.compile(rf"^##\s+{re.escape(heading)}\s*$", re.MULTILINE)
    match = pattern.search(text)
    if not match:
        return ""
    rest = text[match.end():]
    next_heading = re.search(r"^##\s+", rest, re.MULTILINE)
    return rest[: next_heading.start()] if next_heading else rest


branch = run(["git", "branch", "--show-current"]) or "unknown"
modified = run(["git", "diff", "--name-only"])
modified_count = len([x for x in modified.splitlines() if x.strip()]) if modified else 0
commits = run(["git", "log", "--oneline", "-5"]) or "none"

journal = Path(".codex/JOURNAL.md").read_text(errors="ignore")[:1500] if Path(".codex/JOURNAL.md").exists() else "none"
current_step = "unknown"
next_phase_gate = "unknown"
if Path("AGENTS.md").exists():
    text = Path("AGENTS.md").read_text(errors="ignore")
    build_sequence = extract_section(text, "Build Sequence")
    unchecked = re.findall(r"^- \[ \]\s+(.+)$", build_sequence, flags=re.MULTILINE)
    gates = re.findall(r"^\*\*Gate:\*\*\s+(.+)$", build_sequence, flags=re.MULTILINE)
    if unchecked:
        current_step = unchecked[0]
    if gates:
        next_phase_gate = gates[0]

print("Project status")
print(f"- Branch: {branch}")
print(f"- Modified files: {modified_count}")
print(f"- Current Build Sequence step: {current_step}")
print(f"- Active gate: {next_phase_gate}")
print("- Recent commits:")
print(commits)
print("- Journal:")
print(journal)
