# Project Operating Guide

Replace this file with the real repo truth before you rely on it.

## Purpose

Describe what this repository does in two or three precise sentences.

## Build Sequence

> Codex: read this on every turn. Find the first unchecked `- [ ]` item. That is the current step.
> Do not skip ahead. Do not begin the next stage until the current stage gate is satisfied.
> Use `/quick <task>` on the first line only for one-off tasks that should bypass this sequence once.

### Phase 1 — Reproduce or specify the current behavior
- [ ] Identify the exact bug, requirement, or acceptance condition for the current work item.
- [ ] Add or locate the smallest failing test or exact reproduction.
- [ ] Run the test command and confirm RED when practical.

**Gate:** current behavior is pinned down with evidence.

### Phase 2 — Implement the smallest passing change
- [ ] Modify only the files needed for the current step.
- [ ] Run the test command again and confirm GREEN for the current step.
- [ ] Do not begin adjacent features, cleanup passes, or future stages.

**Gate:** the current step is green and bounded.

### Phase 3 — Simplify, validate, and audit
- [ ] Simplify the changed files without changing behavior.
- [ ] Run the test command after each meaningful simplification step.
- [ ] Produce the audit table: Item | Complete % | Reason | Suggestion.
- [ ] Stop and ask whether to implement the suggestions.

**Gate:** tests are passing, the audit is evidence-based, and the repo is resumable.

## Test Command

Replace this with the real repo command, for example `npm test`, `pnpm test`, `pytest`, or `go test ./...`.

## Standard commands

Fill these in with the real commands.

- Setup: `REPLACE_ME`
- Unit tests: `REPLACE_ME`
- Integration tests: `REPLACE_ME`
- Lint: `REPLACE_ME`
- Types: `REPLACE_ME`
- Format: `REPLACE_ME`
- Dev server: `REPLACE_ME`

## Mandatory operating rules

1. Build Sequence enforcement is the default for implementation prompts.
2. `/quick <task>` bypasses Build Sequence enforcement for one prompt only.
3. Run the narrowest relevant validation after each meaningful step.
4. Preserve unrelated user changes.
5. Keep changes reviewable and bounded.

## Skills to use in this repo

- Use `$six-step-loop` for code changes, bug fixes, and refactors.
- Use `$feature-workflow` when working through a staged spec or TODO sequence.
- Use `$ratchet-evolve` only for prompt, instruction, or workflow ratchet work.
- Use `$project-status` when you need a fast evidence-based repo summary.

## Directory-specific notes

Add local instructions here or add nested `AGENTS.md` files deeper in the tree.

### Frontend

- Keep presentational components light.
- Separate UI state from domain logic.
- Test at the actual breakpoints this repo cares about.

### Backend

- Surface explicit error paths.
- Prefer typed or structured failure responses.
- Add regression coverage for externally visible behavior.

## Repo facts

Document the real facts here:

- package manager
- test runner
- framework versions
- deployment constraints
- security boundaries
- directories that should not be edited casually
