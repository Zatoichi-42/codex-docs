#!/usr/bin/env bash
set -euo pipefail

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(pwd)"

mkdir -p   "${REPO_ROOT}/.codex/hooks"   "${REPO_ROOT}/.codex/agents"   "${REPO_ROOT}/.agents/skills"   "${REPO_ROOT}/config"   "${REPO_ROOT}/scripts"

cp "${SRC_DIR}/project-template/AGENTS.md" "${REPO_ROOT}/AGENTS.md"
cp "${SRC_DIR}/project-template/.codex/config.toml" "${REPO_ROOT}/.codex/config.toml"
cp "${SRC_DIR}/project-template/.codex/hooks.json" "${REPO_ROOT}/.codex/hooks.json"
cp -R "${SRC_DIR}/project-template/.codex/hooks/." "${REPO_ROOT}/.codex/hooks/"
cp -R "${SRC_DIR}/project-template/.codex/agents/." "${REPO_ROOT}/.codex/agents/"
cp -R "${SRC_DIR}/project-template/.agents/skills/." "${REPO_ROOT}/.agents/skills/"
cp "${SRC_DIR}/project-template/config/evolution-config.toml" "${REPO_ROOT}/config/evolution-config.toml"
cp -R "${SRC_DIR}/project-template/scripts/." "${REPO_ROOT}/scripts/"
chmod +x "${REPO_ROOT}/.codex/hooks/"*.py || true
chmod +x "${REPO_ROOT}/scripts/"*.py || true

echo "Installed project Codex bootstrap into ${REPO_ROOT}"
echo "IMPORTANT: edit ${REPO_ROOT}/AGENTS.md before trusting the workflow"
